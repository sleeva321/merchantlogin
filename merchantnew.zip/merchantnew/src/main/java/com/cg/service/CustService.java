package com.cg.service;

import java.util.List;



public interface CustService {
	 public int loginByUsername(String uName, String pwd);
	/* public boolean changePwd( int id,String oldpassword, String newpassword, String confirmpassword);
	 public void addToCart(Cart cart) ;
	 List<Cart> getAllCartItems();
	 List<Wishlist> getAllItems();
	public void  addToWishlist(Wishlist wishlist);
	*/
}
